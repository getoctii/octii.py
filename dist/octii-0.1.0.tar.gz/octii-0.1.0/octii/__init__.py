"""
A simple library to make self bots on octii.chat
"""
__version__ = "0.1.0"