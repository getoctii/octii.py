class Users:
    def __init__(self, id, username, avatar, discriminator) -> None:
        self.id = id
        self.username = username
        self.avatar = avatar
        self.discriminator = discriminator
