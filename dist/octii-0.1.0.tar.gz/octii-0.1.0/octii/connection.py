import requests


class connection:
    def __init__(self) -> None:
        self.base_url = "https://api.chat.innatical.com"
